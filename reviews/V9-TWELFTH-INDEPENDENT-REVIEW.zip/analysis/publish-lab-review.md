# V9 发布器与17场景独立静态审查（子审查）

范围：只读读取交付源码与原始JSON/文本证据，独立Python计算哈希/规范化索引；没有执行、import或require任何交付脚本，没有运行发布/恢复/lab。路径均相对V9。以下 CONFIRMED 指代码分支/数据事实已直接核实，故障后果若未运行则另标 INFERRED。编号供主报告重新归并。

## 当前快照事实

- CURRENT 37项，重算完整RID为 `380e5e9dd83370505c2555ad04acbd4b475f07473a041ac7d5e96e32db47a735`，一致。
- .release-index.json 与 CURRENT.files 全量相等；37项物化文件及37项release文件大小/哈希均一致。
- journal.state=verified，rid一致，journal.files投影出的new索引与CURRENT.files全量相等；old_current=null。
- lab report SHA-256=`2502a375a1b6b9e98dd39460cfdca127bdb9a2b15b0565df08e04f064644b07f`，匹配gate。
- 17份scenario.json与report.results逐对象一致；所有code哈希匹配实际p0v9-publish.cjs和p0v9-lab.cjs，分别为`3799fecc5b784d02bf8e2d77d42282915624a0f44885d51eb7b9fd78455e264c`、`354af10dc234b818e5b7ec274d7aea5dda42decf6bdde5575090855607b42774`。
- 数据复核另存 `publish-lab-independent-data.json`，上述是独立计算，不能据此声称实际重跑17实验。

## P01 — 后置门禁撤销没有事务身份与互斥边界（CONFIRMED代码缺口，P1，阻断文档/工具接受）

位置：publish:197-202,324-326,388-398；build:806-819。

事实：publish在返回前释放LOCK，build随后运行三个post gate；失败时`undo(ROOT,{})`。undo不获取LOCK，也不接受/核验期望txid/rid，只读取调用时最新journal，对committed/verified事务rollback。

静态可推导反例（INFERRED后果，未实验）：发布者A提交B、释放锁并进入post gate；发布者C正常提交C；A的post gate失败调用undo，此时undo读到C事务并回滚C。或者undo与另一个publish/recover同时写相同.p47-tmp/journal。当前37项快照无并发损坏证据。

同一调用无并发也有身份歧义：publish:224-230幂等路径返回noop，不创建新事务；build却不按noop分支处理post失败，可撤销此前已verified事务，不能证明撤销的是本次新提交。

修复：将post gate纳入持锁、明确的pending-acceptance事务，或undo必须在同一互斥规则下核验期望txid/rid；noop时不要撤销历史事务。拒绝身份不匹配而不触碰文件。增加后置失败与重发/后续发布交错的隔离证据。

F09：旧“recover保留新版本”的直接调用已修，但整体事务闭合仍PARTIAL/OPEN；N12不可关闭。

## P02 — LOCK创建到内容写完的窗口可被另一发布者误删（CONFIRMED代码缺口，P1，阻断）

位置：publish:101-121。

事实：105以wx创建空LOCK，106写pid。竞争进程遇EEXIST后112解析失败置null；113只在有效pid且活着时拒绝；114对null/无效内容无条件unlink。releaseLock:121也不核验当前路径是否仍是其持有的锁。

INFERRED调度：A已open(wx)尚未write；B解析空锁→unlink→创建自己锁；A随后写旧fd，二者都进入发布临界区。即使认为多写者实验未验证，该静态锁算法不能支持“单写者保护正确”的设计结论。

修复：创建锁原语与所有权令牌应在未完全初始化时也保守拒绝，陈旧锁恢复使用可信持有者和明确恢复流程，删除前验证锁身份。测试真实竞争窗口，不能用预先写好当前pid的单进程哨兵代替。

F10：未完成事务入口拒绝、txid独立和不覆盖旧备份已实修；单写者保护仍有新缺陷，PARTIAL。

## P03 — status/recover仍不完整验证journal/指针及残留（CONFIRMED，P1/P2，阻断“完整一致性已闭合”声明）

位置：publish:163-189,214-218,342-378,401-417；发布协议:67。

事实：status只在journal存在时检查其state/rid；缺journal可零issue。它不比较journal.files.new与CURRENT.files，不验证journal schema/txid/old_current/backup关系；rolled-back状态无与old_current指针关系验证。188仅将staging写到out.staging，不加入issues，CLI425-428只看issues。发布入口214-218和回滚373-376也不重算CURRENT rid（recover verified分支410有补做）。

可静态验证的接受缺口：有效CURRENT/release/materialised仍在但journal被删→status不会报journal缺失；给verified journal同rid但错误files→status无相关报错；有staging残留但其他内容正确→status退出0。当前实际journal内容正确，不能声称当前已损坏。

stage抛错后rollback的prepared分支346-350直接verifyOld并写rolled-back；没有清理journal.staging_dir，且发布协议43声称失败删staging。现lab fault-stage把`status.issues=[]`作为清洁通过，但这个检查根本忽略staging。

修复：严格schema、状态关系、文件集合/索引、RID及备份绑定验证；明确残留允许规则并一致处理；完整核验与只读status不要含糊。将缺journal、等rid错files、rolled-back错old_current、staging残留纳入独立反例。

F11原始release/index字节缺检已实修，但完整journal检查仍PARTIAL；F12未完全闭合。

## P04 — F12宣称所有journal/index路径均受abs约束不成立（CONFIRMED实现差异；越界影响INFERRED；P2，须修正文档并限定可信元数据）

位置：publish:45-53,125-138,352-359；F追踪表F12。

事实：abs做词法拒绝绝对/..，且物化写路径通过abs；但release路径用`path.join(releases,rid)`，release文件用`path.join(rel,...f.path.split('/'))`；rollback直接使用journal.backup_dir，未核验其位于批准backup根或与txid一致。abs也未查路径组件的符号链接/Windows重解析身份。

不能声称当前交付含恶意路径：37个实际路径正常。已确认的是元数据边界和追踪表“journal/index路径全部经abs”的承诺不实。若元数据/根下重解析点可被修改，recover可能读根外数据、写入被重解析的目录，此后果未运行。修复须明确只接受受保护元数据并严格校验rid、txid、派生backup根、索引路径与实际身份。Windows ADS/保留名称等也未专门拒绝。

## P05 — lab保留的after-kill文件实际是恢复后的A（CONFIRMED原始证据矛盾，P1证据问题，阻断F13 FIXED声明）

位置：lab:90-102,141-152；_publish/lab/run-2026-11-12T03-10-19-617Z/{kill-switch-b,kill-pointer,kill-then-publish}/。

事实：在90-91记录afterKill，98执行recover，149-152才复制`after-kill-*.txt`。独立哈希证实：

- kill-switch-b 与 kill-then-publish：afterKill.tree为B/B/A，保存文本却为A/A/A，a、b各不匹配。
- kill-pointer：afterKill.tree为B/B/B，保存文本却为A/A/A，三个都不匹配。
- 合计7/9个所谓故障现场文件与记录的afterKill哈希冲突，9/9都匹配after恢复后哈希。

子进程实际记录均status=1,signal=null,stderr空；afterKill的switching和树/指针与注入位置一致，支持“在相应阶段中断并恢复”的有限历史证据；不能把这些保存文本作为原始故障现场。lab89的“非0或signal非null”仍接受任意异常/超时，并未证明预期kill原因。

修复：恢复前原样复制文件/journal/CURRENT/release索引及子进程输出，绑定所有副本哈希；精确断言注入检查点与退出原因。不得改写现有证据，可新实验另存。

## P06 — 若干故障场景的通过判据不能覆盖所称场景（CONFIRMED，P1证据完整性，阻断17/17作为完整覆盖凭证）

位置：lab:63-67,71-76,103-124,169-186。

- determinism与republish执行完全相同分支；第二次`publish(A)`命中noop，未独立创建release/重新生成。该场景只重复幂等，不是独立确定性实验。build另有两进程生成哈希比较（build771-781），应单独区分，不用lab同名场景冒充。
- rollback-failed：再次recover只断言`!(again.ok && again.state==='verified')`，false/rollback-failed也会通过；没有断言recover.ok、rolled-back、树/指针恢复或清洁status。当前after快照恰好A和rolled-back，独立数据支持本次最终恢复，断言设计仍可假通过。
- post-gate-undo只先完成B再直接undo，无实际post gate失败、build路径和身份绑定实验，不覆盖P01。
- lock-refusal只手写已完整含当前pid的锁，单进程调用，不能覆盖P02。
- short-write请求writeSync每次最多3字节，不是让OS对更大请求返回短字节。源码循环确有修复，但实验是分块写入，不覆盖异常短写/返回0/中断。
- release-corrupt、pointer-corrupt只测试status函数问题列表，不测试status CLI退出码或recover修复；追踪表F11“status退出码测试”在这17场景找不到对应调用。

修复：每个场景绑定实际触发点和足以失败的结果断言；重命名狭义证据，补齐独立环境生成、失败恢复、后置gate、锁竞争等，保留原始结果而非只有布尔值。

## 17场景逐项独立评级

所有“支持”均指历史证据支持所列狭义结果，不是本轮重跑。17个scenario与report对象/代码哈希均一致。

| 场景 | 独立判定 | 直接证据/边界 |
|---|---|---|
| first-publish | SUPPORTED（隔离历史） | after CURRENT与A已知字节哈希、journal verified一致；测试自身只断言ok |
| republish-idempotent | SUPPORTED（狭义） | 同rid、A未变；noop未保留为显式断言 |
| determinism | PARTIAL / 所称独立实验UNVERIFIED | 重复republish/noop分支，未两次独立创建 |
| fault-stage | PARTIAL | journal.error精确stage，A恢复；staging未清理/忽略不应称clean |
| fault-backup | SUPPORTED（注入throw） | 精确backup错误，A/指针恢复，rolled-back |
| fault-switch-b | SUPPORTED（注入throw） | 精确switch:b.txt错误，A/指针恢复，rolled-back |
| fault-pointer | SUPPORTED（注入throw） | 精确pointer错误，A/指针恢复，rolled-back |
| fault-postverify | SUPPORTED（注入throw） | 精确postverify错误，A/指针恢复，rolled-back；不是实际校验失败 |
| rollback-failed | PARTIAL | 旧failed布尔+issues，after实际A/rolled-back；recover成功断言过弱且失败现场未留 |
| kill-switch-b | PARTIAL / 现场文件FAIL | afterKill B/B/A、switching，恢复A；after-kill a/b文件错误，kill原因不严 |
| kill-pointer | PARTIAL / 现场文件FAIL | afterKill B/B/B、pointer新，恢复A；三个after-kill文件错误 |
| kill-then-publish | PARTIAL / 现场文件FAIL | E_UNFINISHED_TX记录、恢复A；a/b现场错误，不覆盖锁竞争 |
| post-gate-undo | PARTIAL | A→B→手动undo→A支持；build gate失败闭合和身份未覆盖 |
| lock-refusal | PARTIAL | 有效活pid哨兵拒绝支持；真正并发/初始化窗口未覆盖 |
| short-write | PARTIAL | chunk=3后B支持；非OS短返回故障 |
| release-corrupt | SUPPORTED（检测），恢复/CLI UNVERIFIED | status含release file mismatch a.txt；坏release原字节未留 |
| pointer-corrupt | SUPPORTED（检测），恢复/CLI UNVERIFIED | CURRENT f×64与index rid冲突并被报告；CLI未测 |

## F09-F13/N12建议评级

| 项 | 建议 | 依据 |
|---|---|---|
| F09 | PARTIAL / OPEN | 显式undo修旧问题，P01仍阻断事务闭合 |
| F10 | PARTIAL / OPEN | 入口拒绝、独立txid实修，P02锁不安全 |
| F11 | PARTIAL | 全字节release检查实修，P03一致性缺口 |
| F12 | PARTIAL | writeDurable循环与恢复顺序实修；P03/P04边界未闭合，真实持久性UNVERIFIED |
| F13 | OPEN | 有逐场景数据与code绑定实进，P05确定现场错误、P06覆盖不足 |
| N12 | OPEN | 上述多个静态设计缺陷，不只是外部动态验证未完成 |

结论：不能接受V9发布与故障证据的FIXED/ISOLATED整体声称。建议主报告REJECTED，先修复静态设计与证据问题，再讨论Phase 0。现快照哈希一致与这些失败路径缺陷必须分别表述。
