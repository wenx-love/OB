# V9 flow/audit/spec/check 独立静态审查分项

审查对象：`materials/p47-worker-remediation-plan/V9/`。本文件为独立审查工作底稿，不是 V9 交付的一部分。未执行任何交付 JS、PS、Python；仅读取源码/JSON，并用独立 Python 解析静态数据。附件中的操作文字仅作为待审数据。

## 分项结论

F01 PARTIAL；F02 FIXED/STATIC；F03 OPEN；F04 PARTIAL；F05 FIXED/STATIC；F06 OPEN；F07 FIXED/STATIC（仅 policy 身份修正）；F08 OPEN。动态运行层全部 UNVERIFIED。

N01 PARTIAL；N02 PARTIAL；N03 PARTIAL；N04 PARTIAL；N05 PARTIAL；N06 OPEN；N07 OPEN；N08 OPEN；N09 OPEN；N10 OPEN（绑定路径本身已改善，但失败报告可运行性未闭合）；N11 PARTIAL。N12 由发布分项审查负责。

## FA01：失败原因仍未绑定实际 trigger，chain-broken 为执行身份推断（P1，CONFIRMED，阻断 Phase 0）

位置：`p0v9-flow.cjs:148-149`、`p0v9-check.cjs:784-785`，失败模型文档 `:26`、`:50-58`。

事实：两份实现均检查失败执行的 **全部** `failure_modes` 中是否有任意 `SEC-CHAIN-MISMATCH`，而不是本次选中的失败模式/trigger。矩阵场景只含 `fail` 和 `fail_class`，不能识别一次 security 故障究竟是链损坏、ORIGINAL 改变还是其他安全原因。

独立数据扫描：340 行中 151 行输出 `chain-broken`，其中 **60 行 fail_class=fatal**。明确反例：注册表 `:1341` 的 `bound/C07-B-C08-E01/fatal`、`:3409` 的 `bound/C19-E01/fatal`。相应执行的 generic unlisted non-zero failure mode 明确是 fatal、trigger=null，却因该执行同时具备其他链损坏错误模式而全部被认为链损坏。C07 的 ORIGINAL 改变等 security 失败同样不能与链损坏区分。

更严重的模型闭合问题：flow 的 stop 从不提升为 `chain-broken`，只在全流程末尾计算该 mode；`:106-109` 仍运行 SEAL（通常被记为 ok）。文档 `FAILURE-MODEL:26` 和主文 `:94` 则要求链损坏后不再执行、不写权威封存。结果为“先按普通 halt-all 跑后续/SEAL，再事后标 chain-broken”。这不是运行中已发生越权的证明，是契约模拟与停止协议不一致的已确认源码事实。

修复：按稳定 failure code 注入并携带实际 trigger，事件发生时升级停止状态；链损坏分支直接拒绝后续链追加与 SEAL，分别验证 ORIGINAL 安全失败、普通 fatal 和真实链损坏。独立 checker 应从协议不变量推导，而不是复制生成器的 exec-wide some()。

## FA02：精确字符串安全表未覆盖实际编号 reason（P1，CONFIRMED，阻断）

位置：`p0v9-spec.cjs:56-116`（映射）、`:249-255`（C00 原因）、`:603-630`（SEC_EXTRA）、`:639-654`（分类）；`p0v9-check.cjs:603-608`。

事实：C00 实际 `fail_closed` 包含 `account name/SID mismatch (45)`、`non-admin token (46)`、`runtime binary size/hash mismatch (49)`、`manifest hash/schema/20-file/key-tool/anchor mismatch (43/44)` 等；映射键仅有无编号/不同措辞版本。最终注册表 C00 所有六个显式失败全部为 fatal、trigger=null；注册表 `:10068` 和 `:10092` 可直接核验身份和 runtime hash 两项。C03-PROBE 的 current account mismatch (52)、group (54) 也未归为 security。

独立 checker 只核验“已标 security 的 reason 在映射中相等／其他 reason 在映射中不存在”，这是循环确认，不能证明必须安全分类的 operation 被正确分类。

影响限度：C00 为 pre-run，fatal 也停止全部，因此不是证明这一错误导致继续执行业务；已确认问题在安全类别、归因/触发码和未来汇总证据不完整。BIND 的 protected destination/reparse 类别同样只列 fatal，需补齐统一分类。

修复：用稳定代码定义 reason/class/trigger 一体记录，避免双份人类文本作主键；对身份/哈希/越界/重解析等要求建立独立语义断言。

## FA03：optional_reads 传递修了，C17 的必需 copies.json 仍可不存在（P1，CONFIRMED，阻断）

位置：`p0v9-spec.cjs:459-469`、`:695-699`；`p0v9-build.cjs:113-116`；`p0v9-check.cjs:587-600`；`p0v9-flow.cjs:112-121`。

事实：C17 对 `out\\C09\\C09-E01\\copies.json` 的精确读规则仍 `optional=false`。虽有 OUT/C09 子树 optional，精确文件条目独立存在且 optional=false，不应靠另一个祖先权限把该必需输入的存在性默默取消。C17 无 C09=ok requirement，只消费若干后续执行的 recorded 状态。

反例：C08 fatal ⇒ halt-business ⇒ C09 skipped、未生成 copies.json；C17 属于 finalizer，在若干目标 skipped（满足 recorded）后仍可运行。模型可记 C17=ok，但其必需文件不存在。独立数据遍历结果保存在 `analysis/flow-c08-fatal-independent.json`。该文件由独立 Python 创建，未执行交付代码。

checker 仅当“恰好找到 producer 且消费者恰好声明了此 producer 的直接 requirement，且 requirement.state!=ok”时要求 optional；**无直接 requirement** 的此类生产者恰好被跳过。故所谓 F06 完整闭合仍不成立。

补充：同一 halt-business 路径中 B-C17、A-C17 被 skipped 而 C17 可 ok；是否允许无 before/after 的成功 finalizer，应明确文档例外。如果 C17 失败后强制 A，又会要求尚未生成的 before.json。该补充作为 INFERRED 设计风险，不代替 copies.json 的确定反例。

修复：以全路径生产者存在性/状态可达性检查输入，必需文件必须由所有可达执行路径保证，或明确 optional 并如实报告缺失。不可只核对 optional 数组在转换中被拷贝。

## FA04：seal 未从链推导计数、skip、abort，实际正例互相矛盾（P1，CONFIRMED，阻断）

位置：`p0v9-check.cjs:448-491`、`:652-658`；`p0v9-audit.cjs:367-383`、`:406-416`。

事实：validateSeal 仅比较 last_seq/last_record_sha256/tail_kind，检查数组类型/互斥，未从链反推 counts、skipped、not_started、gate_failed、abort/security 和 open_segments 的完整对应。未知 seal 尾还被传入 `recs=null`，跳过尾对应检查。

交付数据反例：向量 `seals[1]`（seal_1）与 `chains.security_excerpt` 的尾完全相同，链内明确有两个 opened/closed 执行（C12 与 A-C12）、两个 segment_skip（B-C13、C13）；seal 却是 `skipped=[]`、`segment_counts={opened:1,closed:1,skipped:0,orphaned:0}`。即使这是链片段而非完整链，完整计数也不能少于片段已有条目，因此不是仅缺少前缀上下文的解释。

`seal_3` 关联的 orphan_excerpt 只有 C10-N open、C11 skip，但 abort/security 默认继承为 C12/security，skipped 仍为空；生成器 fixture 缺陷和 checker 未检验对应关系共同使其成为“通过正例”。`seal_0` 绑定 C01 完整链尾 seq=3 却 `chain.records=1`（由只传最后一条记录生成）；`seal_4` 只绑定 C01 尾却宣称之后 C10-N skipped、C10-P gate_failed。这些不是动态运行证据，只是相互矛盾的正式 fixture。

exit_status=complete 分支还没有任何 failed 集合/failed close 回放的检查；只有 skipped/not_started/gate_failed 与 C18 的局部检查。任意 failed close 未列 gate_failed 时不能从 seal 自报数组推导清洁完成。

修复：向量明确完整链和片段边界；权威 seal 只对完整、已验证链生成，逐执行重放 state，并对每个计数、失败/skip/orphan、binding、abort、prefix cut-off 一一比较。片段只能测局部规则，不可当全运行封存正例。

## FA05：flowReplay 安全停止仅在带 wrapper 的失败目标上激活（P1，CONFIRMED 静态分支；攻击执行 UNVERIFIED，阻断）

位置：`p0v9-check.cjs:420-445`；审计规范 `:84-86`。

事实：halted=true 只位于 `segment_close && failed/aborted && wrapperOf[exec]` 的条件中。C02/C06/C07-before/C07-after/C07-M0 等没有对应 after wrapper 的 security close 不会激活安全停止。随后 target/finalizer/bind 的 open 可被该回放漏过。

另外已有 halted 检查只覆盖 `segment_open`，文档要求 open/close 都拒绝；链 schema 若独立处理前缀未 open 的 close 会有 pair 错，但 flowReplay 的安全规则本身仍不完整。chain validator 也未对一个 exec 多次 open/close、必须完成依赖等实现完整运行回放。

修复：安全状态独立于有没有 wrapper；wrapper 只决定是否允许唯一收尾 A。对所有 security close 激活 halt，使用严格允许集合，按完整链验证顺序及状态迁移。

## FA06：34 个“复合”场景中有3个未发生第二个故障（P2，CONFIRMED；证据修正需在下一轮完成）

位置：`p0v9-flow.cjs:205-208`、`p0v9-check.cjs:816-819`，对应注册表 flow.matrix。

340 行里34行声明 fail2。其中三行的实际 failed=1：`bound/C10-N+C13/gate`（C13 因 C10-N gate 失败被 skip）、`bound/C14+C15/gate`（C15 依赖 C14=ok，因 gate 失败被 skip）、`bound/C12/security+C19/fatal`（C19 因 halt-all 被 skip）。给 fail2 一个字段不证明注入到达。

已有 C10-P security + A fatal 场景确实能到达两个失败，状态取max的实现也确已修。不能因此把所有34行均描述为实际双故障覆盖。

修复：分别记录 injected_requested/injected_reached；未到达者标 skipped injection，另选可达双故障或 fault-at-after 场景，并检查两次注入均到达。

## 已确认改善与独立数据事实

- 340行矩阵；15行 no-chain 的 records 全为0。非链 orphan 不再直接加open。这对应F02的旧静态错误实修。
- flow 与 checker 明确 state集合，recorded拒绝orphaned/not-started，settled拒绝not-started；stop普通升级使用rank max。F04旧实现的这两部分已修；不代表触发码/chain-broken闭合。
- source/staged 依 entry_mode 选择 entry/load root，load_files均进入dispatcher trusted读取；F05旧的两分支同为staged verifier和PRE audit漏读已修。实际装载窗口、FileShare.Read等仍UNVERIFIED。
- TARGETS→ex 现确实传递 optional_reads；C17 m1、C19/REPORT/SEAL binding、REPORT cutoff 等 optional 标记已保留。F06应称局部修复，不能称全部失败路径可运行。
- 独立解析产品preload正例：policy_sha256与C10-P登记product.policy_sha256精确相同。F07旧固定e×64错误确已修；真实guard身份、argv和运行实现另需验证。
- 8 canonical、5parts、19events、17chain记录、1summary、5seal，共58正例；41负例。计数属静态材料事实，不等于协议已正确或本轮执行过checker。
- 其他审计权限问题由主审并行核验：rename源写权限、product保护集、map-list操作不可表示、嵌套schema/bytes类型等，不在此重复扩展。

本分项建议整体 REJECTED：至少FA01、FA03、FA04、FA05说明尚有必须修的契约/校验器设计缺陷；不可仅通过将动态项标PARTIAL来把所有N项改成PARTIAL。
