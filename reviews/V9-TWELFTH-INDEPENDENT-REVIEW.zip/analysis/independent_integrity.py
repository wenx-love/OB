from pathlib import Path
import json,hashlib,re,csv
B=Path('/workspace/p47-independent-review/materials/p47-worker-remediation-plan'); V=B/'V9'; O=Path('/workspace/p47-independent-review/analysis')
def sha(b): return hashlib.sha256(b).hexdigest()
def measure(p):
 b=p.read_bytes(); return dict(bytes=len(b),lines=len(b.splitlines()),sha256=sha(b))
def canon(v): return json.dumps(v,ensure_ascii=False,separators=(',',':'),sort_keys=True)
issues=[]; rows=[]
pat=r'^\| `([^`]+)` \| (\d+) \| (\d+) \| `([0-9a-f]{64})` \|$'
for m in re.finditer(pat,(V/'PHASE4.7-PHASE0-V9-DELIVERY-MANIFEST.md').read_text(),re.M):
 f,n,l,h=m.groups(); a=measure(V/f); ok=a==dict(bytes=int(n),lines=int(l),sha256=h)
 rows.append(dict(path=f,**a,match=ok));
 if not ok:issues.append('manifest mismatch '+f)
cur=json.loads((V/'_publish/CURRENT.json').read_text()); rid=sha(canon(cur['files']).encode()); r=V/'_publish/releases'/cur['rid']; idx=json.loads((r/'.release-index.json').read_text());j=json.loads((V/'_publish/journal.json').read_text())
assert rid==cur['rid']; assert idx==cur['files'];assert j['state']=='verified' and j['rid']==cur['rid']
for f in cur['files']:
 for root in [V,r]:
  a=measure(root/f['path'])
  if a['bytes']!=f['bytes'] or a['sha256']!=f['sha256']:issues.append('current/release mismatch '+str(root/f['path']))
byj={f['path']:f['new'] for f in j['files']};byc={f['path']:{k:f[k] for k in ['bytes','sha256']}for f in cur['files']}
assert byj==byc
assert set(byc)=={x['path']for x in rows}|{'PHASE4.7-PHASE0-V9-DELIVERY-MANIFEST.md'}
release_actual={p.relative_to(r).as_posix()for p in r.rglob('*')if p.is_file()}
assert release_actual==set(byc)|{'.release-index.json'}
work=[]
for p in V.glob('p0v9-*'):
 q=V/'work'/p.name;work.append({'path':p.name,'work_present':q.exists(),'equal':q.exists()and q.read_bytes()==p.read_bytes()})
source=[]
for p in (V/'doc-src').glob('*.md'):
 q=V/p.name
 if '<!-- GENERATED:BEGIN' in p.read_text():
  equal=p.read_text().split('<!-- GENERATED:BEGIN')[0]==q.read_text().split('<!-- GENERATED:BEGIN')[0];kind='prefix'
 elif p.name.endswith('SELF-CHECK.md'):equal=None;kind='placeholders'
 else:equal=p.read_bytes()==q.read_bytes();kind='exact'
 source.append({'path':p.name,'comparison':kind,'equal':equal})
report=B/'CODEX-P47-PHASE0-V8-ELEVENTH-INDEPENDENT-REVIEW-20261112-104806.md'
v8=[]
for m in re.finditer(r'^\| ([^|]+?) \| (\d+) \| (\d+) \| ([0-9a-f]{64}) \|$',report.read_text(),re.M):
 f,n,l,h=m.groups();p=B/'V8'/f.strip();a=measure(p);ok=a==dict(bytes=int(n),lines=int(l),sha256=h);v8.append(dict(path=f.strip(),**a,match=ok))
 if not ok:issues.append('v8 mismatch '+str(p))
allfiles=[]
for p in V.rglob('*'):
 if p.is_file():allfiles.append(dict(path=p.relative_to(V).as_posix(),**measure(p)))
with (O/'v9-all-files-independent-sha256.tsv').open('w')as f:
 w=csv.DictWriter(f,fieldnames=['path','bytes','lines','sha256'],delimiter='\t');w.writeheader();w.writerows(sorted(allfiles,key=lambda x:x['path']))
out={'v9_manifest':rows,'v9_manifest_self':measure(V/'PHASE4.7-PHASE0-V9-DELIVERY-MANIFEST.md'),'v8_history':v8,'eleventh_review':measure(report),'rid_recomputed':rid,'current_files':len(cur['files']),'journal_new_equal':byj==byc,'work':work,'doc_src':source,'v9_allfiles_count':len(allfiles),'issues':issues}
(O/'integrity-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in out.items()if k not in ['v9_manifest','v8_history','doc_src','work']},ensure_ascii=False,indent=2));print('manifest',len(rows),'v8',len(v8),'work equal',sum(x['equal']for x in work))
