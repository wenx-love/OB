# V9 integrity / generation closure / traceability independent review

This subreview only reads extracted material and independently computes SHA-256 / byte counts / parses documents. No delivered CJS, PS1, Python helper, publisher, recovery, lab, Phase 0 command or browser was executed. Independent tools and outputs are outside the material directory.

## Independently established current snapshot

- Manifest has exactly 36 unique rows: 13 contracts, 13 tools, 10 doc-src inputs. Every byte count, line count and SHA-256 matches raw bytes.
- Manifest itself: 6998 bytes / 95 lines / SHA-256 `be38bfb6035f5edeefe98fcd26a4167b46668825567fb15529da7df00864264c`.
- CURRENT has exactly the manifest's 36 paths + manifest itself = 37 paths. No missing/extra path relative to the declared package.
- CURRENT RID independently recomputed from recursively key-sorted compact JSON of files: `380e5e9dd83370505c2555ad04acbd4b475f07473a041ac7d5e96e32db47a735`, exact match.
- Current release index exactly equals CURRENT.files, all 37 release files and all 37 materialized files match index bytes/hash, and release contains only those files + `.release-index.json`.
- journal.state is verified, rid matches CURRENT, every journal.files[].new matches CURRENT corresponding byte count/SHA-256, exact path set.
- 13 root tools match 13 work copies byte-for-byte. Ten root doc-src inputs match ten work/doc-src copies byte-for-byte. Pure-copy generated documents match source. Generated main/audit prefix before GENERATED marker matches source; SELF-CHECK is parameterized.
- Independently measured every V9 file including work/evidence/release: 245 files. Full raw file manifest saved `v9-all-files-independent-sha256.tsv`.
- V8's 26 top-level deliverables independently match the byte count / lines / SHA-256 in the supplied eleventh independent report. That report itself is 26616 bytes / 352 lines / SHA-256 `9f9b4c7ee4976312625a697c059b0692c20df07e9a8b748d4e0847092392f1bc`, matching V9 input identity. This proves the known 26-file historical baseline, not every unrecorded historical work/lab byte since the previous review.
- Evidence and exact results: `independent_integrity.py`, `integrity-results.json`, `v9-all-files-independent-sha256.tsv`.

## I14-A / F14 PARTIAL: full reproduction still requires an undisclosed historical bundle

**CONFIRMED / P2**. Source: `PHASE4.7-PHASE0-V9-DELIVERY-MANIFEST.md:58,63`, `p0v9-build.cjs:790,816-822`, `p0v9-check.cjs:995-999`, `p0v9-hygiene.cjs:69-79`. Trace claims FIXED/STATIC at `PHASE4.7-PHASE0-V9-F01-F14-TRACEABILITY.md:24` (F14 row; line may be located by exact F14 row).

The substantive V8 template omission is fixed: 10 inputs are bound to manifest/release, generator prefers packaged doc-src (`build:17,709-727`) and all current input bytes match. But the manifest claims only the formal 37-file package is needed to reproduce and gives full build/gate/publish as the reproduction command. That build obligatorily invokes a checker that fails all 26 V8-present checks when external V8 is absent; post-gate hygiene obligatorily reads both V7 and V8 outside the package. Those files are not part of 37-file release, not declared among reproduction prerequisites, and checker uses location-dependent upward candidates. Consequently **pure generation input closure is improved and statically closed for the current inputs; the documented full gate/publish reproduction closure is not self-contained**. We did not execute a reproduction because the review prohibits running the publisher/lab.

Risk: a reviewer copying only the declared delivery cannot complete documented reproduction; a byte-stable generator can still fail its gate due solely to unbundled history. Fix by defining generation-only vs full historical gates separately, declaring/pinning the historical baseline bundle/path as an external verification prerequisite, or including a read-only baseline package. Do not remove historical checks just to pass. This is a documentation/reproducibility defect; it should be corrected before claiming complete F14 remediation. It is not independent proof that current snapshot is corrupt.

## I14-B / F11+F14 checker membership gap

**CONFIRMED static omission / P2**. Source `p0v9-check.cjs:894-927,941-964`; `p0v9-build.cjs:724-727,744-745`; `p0v9-manifest.cjs:55-80`.

The checker verifies all manifest fixed paths, and separately loops over whatever CURRENT.files supplies. It never equates CURRENT.files path set to manifest rows + manifest itself. An internally consistent subset (including empty list) for CURRENT/index, with matching RID and journal, does not trigger those pointer checks even though required materialized files are outside the pointer's bound set. Likewise generator dynamically includes any `p0v9-*.cjs|ps1` and extra doc-src markdown, while manifest renderer only renders fixed names and checker compares that fixed list to the same fixed expectation, not the generated/published file set. This is a generator/checker common membership blind spot. Current actual 37-member set was independently compared and is correct; no current omission or malicious extra file is alleged.

Fix: define a unique authoritative expected package membership, check it bidirectionally against generated docs, parsed manifest+self, CURRENT and release physical/index sets. Keep approved auxiliary evidence/work explicitly outside that formal membership. Whether blocker: must close before relying on checker alone as complete delivery trust-chain gate; current release consistency is independently established.

## R01-R25 independent scope rating

No R item is marked CLOSED in V9. `START-CONDITIONS:11` retains 0 CLOSED / 23 PARTIAL / 2 OPEN; `OPEN-ISSUES:49-51` explicitly preserves R05 and R16 OPEN / R01 PARTIAL and disclaims product implementation or runtime evidence. Thus there is no unsupported closure in the V9 declarations. Original R01-R25 titles and pending checks are explicitly enumerated in `PHASE4.7-V5-CODEX-FINDINGS-TRACEABILITY.md:24-48`; the superseding independent ratings are in `CODEX-P47-V5-FIFTH-INDEPENDENT-REVIEW.md:164-190`. This subreview checked those source rows rather than treating the V5 self-trace ratings as final.

R05 remains OPEN on direct reading of archived V5 candidate (`PHASE4.7-WORKER-REMEDIATION-PLAN-V5-CANDIDATE.md:456-459,466`): per-request placeholderSeq must agree before merging, while same-identity non-force requests must merge. R16 remains OPEN (`:356-370,618-619`): exact full commitToken/epoch/session criteria conflict with legacy container commitSeq >= target criterion. V9 has no revised product specification or implementation to resolve either.

All other R items remain PARTIAL in this contract-only submission: their actual products, UI, browser/performance, guard/ACL and promotion evidence are absent or explicitly not run. This is an independent determination about the present delivery scope, not a renewed validation of all earlier product designs.

| Item | Rating | Still absent / reason |
|---|---|---|
| R01 | PARTIAL | final settlement/promise lifecycle implementation + dynamic cancellation |
| R02 | PARTIAL | cancellation race / pump implementation evidence |
| R03 | PARTIAL | breaker / health classification dynamic proof |
| R04 | PARTIAL | stale event / generation callback runtime proof |
| R05 | OPEN | placeholderSeq merge conflict remains; no revised product spec |
| R06 | PARTIAL | cache limits and eviction runtime proof |
| R07 | PARTIAL | deferred admission/explicit rejection runtime proof |
| R08 | PARTIAL | scheduler/show order and starvation observations |
| R09 | PARTIAL | timeout/performance dynamic proof |
| R10 | PARTIAL | attempts/retry settlement runtime proof |
| R11 | PARTIAL | refresh/source/URL/epoch runtime proof |
| R12 | PARTIAL | SW reset / late event runtime proof |
| R13 | PARTIAL | current state / historical counter runtime proof |
| R14 | PARTIAL | actual A/B worker build/load proof |
| R15 | PARTIAL | actual product input/bundle closure and sidecar trust proof |
| R16 | OPEN | exact token vs old high-water criterion conflict remains |
| R17 | PARTIAL | real panel full result capture and harness boundary |
| R18 | PARTIAL | all deadline/render priority behavior runtime proof |
| R19 | PARTIAL | product schema implementation/hash-envelope evidence |
| R20 | PARTIAL | real copy/plugin observation runtime proof |
| R21 | PARTIAL | persistRun / refusal and history protection evidence |
| R22 | PARTIAL | real guard/read-write/FD/native matrix |
| R23 | PARTIAL | final promotion tree/reverse mapping verification |
| R24 | PARTIAL | real ADS and unknown-change attribution evidence |
| R25 | PARTIAL | account/ACL/second archive/independent execution authorization |

F01-F13 and N states should use the independent flow/audit/publish subreviews; this subreview does not endorse V9's 14/14 claim.
