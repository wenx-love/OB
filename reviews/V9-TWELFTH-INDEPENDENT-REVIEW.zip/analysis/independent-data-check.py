"""Independent read-only analysis of uploaded data; never imports or executes delivery code."""
import json, hashlib, pathlib, csv, io
ROOT=pathlib.Path('/workspace/p47-independent-review/materials/p47-worker-remediation-plan/V9')
OUT=pathlib.Path('/workspace/p47-independent-review/analysis')
def h(b): return hashlib.sha256(b).hexdigest()
def canon(v):
 if v is None: return 'null'
 if v is True: return 'true'
 if v is False: return 'false'
 if isinstance(v,int):
  assert abs(v)<=2**53-1
  return str(v)
 if isinstance(v,str):
  return '"'+''.join('\\"' if c=='"' else '\\\\' if c=='\\' else '\\u%04x'%ord(c) if ord(c)<32 else c for c in v)+'"'
 if isinstance(v,list):return '['+','.join(map(canon,v))+']'
 if isinstance(v,dict):return '{'+','.join(canon(k)+':'+canon(v[k]) for k in sorted(v))+'}'
 raise TypeError(type(v))
def hc(v):return h(canon(v).encode())
r=json.loads((ROOT/'PHASE4.7-PHASE0-COMMAND-EXECUTION-REGISTRY-V9.json').read_bytes())
v=json.loads((ROOT/'PHASE4.7-PHASE0-AUDIT-VECTORS-V9.json').read_bytes())
es=r['executions'];by={e['exec_id']:e for e in es}
vecs=sum([v[k] for k in ['valid','parts','events','summaries','seals']],[])+sum(v['chains'].values(),[])
checks=[]
for x in vecs:
 b=x['canonical'].encode();checks.append({'name':x['name'],'canonical_ok':canon(json.loads(x['canonical']))==x['canonical'],'bytes_ok':len(b)==x['bytes'],'sha256_ok':h(b)==x['sha256']})
argv=[e['exec_id'] for e in es if hc(e['argv'])!=e['argv_sha256']]
target=[e['exec_id'] for e in es if e.get('target_argv') and hc(e['target_argv'])!=e['target_argv_sha256']]
inline=[e['exec_id'] for e in es if e['entry_mode'] in ['inline','codex-inline'] and h(e['argv'][-1].encode())!=e['inline_sha256']]
guard=[];product=[]
for e in es:
 if e.get('guard'):
  p={'deny':e['deny_read'],'read':[[x['path'],x['kind']] for x in e['reads']['business']],'write':[[x['path'],x['op']] for x in e['writes']['business']],'parts':e['audit_part_rule'],'protect':e['protect_write']}
  if hc(p)!=e['guard']['policy_sha256']:guard.append(e['exec_id'])
 if e.get('product'):
  q=e['product'];p={'deny':q['deny_read'],'read':[[x['path'],x['kind']] for x in q['reads']],'write':[[x['path'],x['op']] for x in q['writes']],'protect':q['protect_write']}
  if hc(p)!=q['policy_sha256']:product.append(e['exec_id'])
# Independent field projection using published header order.
rows=list(csv.DictReader(io.StringIO((ROOT/'PHASE4.7-PHASE0-COMMAND-READ-WHITELIST-V9.tsv').read_text()),delimiter='\t'))
def reads(xs):return ';'.join(('T:' if x['kind']=='subtree' else 'M:' if x['kind']=='metadata' else 'F:')+('?' if x.get('optional') else '')+x['path'] for x in xs)
def writes(xs):return ';'.join(x['op']+':'+x['path'] for x in xs)
def ss(x):return '' if x is None else str(x)
mismatches=[]
for e,row in zip(es,rows):
 p={k:ss(e.get(k)) for k in ['exec_id','command_id','variant','step','class','plan_order_bound','plan_order_unbound','predecessor_bound','predecessor_unbound','executor','entry_mode','entry_path','cwd','argv_sha256','inline_sha256','chain_role','conditional','deadline_seconds','gate','fail_class']}
 p.update(temp_mode=e['temp']['mode'],temp_path=e['temp'].get('path') or '',tool_files=';'.join(x['path'] for x in e['tool_files']),load_files=';'.join(e['load_files']),audit_roles=','.join(e['audit_roles']),deny_read=';'.join(e['deny_read']),protect_write=';'.join(e['protect_write']),guard_policy_sha256=(e.get('guard') or {}).get('policy_sha256',''),requires=';'.join(x['state']+':'+x['exec']+':'+x['kind'] for x in e['requires']),outputs=';'.join(x['code']+':'+x['path'] for x in e['outputs'] if x['code']!='CONSOLE'),failure_modes=';'.join(x['code']+'='+x['class']+('('+x['trigger']+')' if x.get('trigger') else '') for x in e['failure_modes']),security_triggers=';'.join(e['security_triggers']))
 for layer in ['dispatcher','business','control']:p[layer+'_reads']=reads(e['reads'][layer]);p[layer+'_writes']=writes(e['writes'][layer])
 for k,want in p.items():
  if row[k]!=want:mismatches.append({'exec':e['exec_id'],'column':k,'actual':row[k],'expected':want})
summary={'vector_count':len(checks),'vector_checks':checks,'argv_mismatch':argv,'target_argv_mismatch':target,'inline_mismatch':inline,'guard_policy_count':sum(bool(e.get('guard')) for e in es),'guard_policy_mismatch':guard,'product_policy_count':sum(bool(e.get('product')) for e in es),'product_policy_mismatch':product,'tsv_rows':len(rows),'tsv_columns':len(rows[0]),'tsv_projection_mismatch':mismatches,'matrix_rows':len(r['flow']['matrix']['rows_data']),'matrix_digest_ok':hc(r['flow']['matrix']['rows_data'])==r['flow']['matrix']['digest']}
(OUT/'independent-data-check.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
# Static counterexample predicates, using only delivered registry data; this does NOT call the checker.
def under(p,q):return p.lower()==q.lower() or p.lower().startswith(q.lower()+'\\')
e=by['C08-E01'];src=r['original']+'\\README.md';dst=r['run']+'\\tmp\\moved-README.md';wi=next(i for i,w in enumerate(e['writes']['business']) if w['op']=='subtree-write' and under(dst,w['path']))
rename={'exec_id':e['exec_id'],'op':'rename','src_path':src,'path':dst,'rule_ref':f"{e['exec_id']}.business_writes[{wi}]",'destination_write_rule':e['writes']['business'][wi],'source_read_covered':any(under(src,x['path']) if x['kind']=='subtree' else src.lower()==x['path'].lower() for x in e['reads']['business']),'source_write_covered':any(under(src,x['path']) if x['kind']=='subtree' else src.lower()==x['path'].lower() for x in e['writes']['business']),'source_protected':any(under(src,p) for p in e['protect_write']),'destination_protected':any(under(dst,p) for p in e['protect_write']),'limitation':'Static predicate witness only. No filesystem rename and no delivered validator was executed.'}
ml=by['C14-E01']['writes']['business'][4]
counter={'rename_source_authorization':rename,'map_list_rule':ml,'map_list_child':ml['path']+'\\src\\extension\\devtools\\panel.ts','read_denied_null_rule':{'normative':'WRITE-AUDIT-SPEC:53 permits denied + rule_ref=null','checker':'check:250-254 unconditionally tests rule layer and rejects null'},'non_byte_write':{'normative':'audit.cjs:57 requires bytes_written=null unless op writes bytes','checker':'check:233-235 requires after.bytes:number and bytes_written=after.bytes for mkdir/acl/delete/rename too'},'scope':'No payload, generator, checker, lab, publish or recover module was executed.'}
(OUT/'static-permission-counterexamples.json').write_text(json.dumps(counter,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:x for k,x in summary.items() if k!='vector_checks'},ensure_ascii=False,indent=2));print('positive_vector_all_ok',all(all(x[k] for k in ['canonical_ok','bytes_ok','sha256_ok']) for x in checks));print('rename witness',json.dumps(rename,ensure_ascii=False))
